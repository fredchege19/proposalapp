
<!doctype html>
<html lang="en">
@include('compo.adminhead')

<body>

@include('compo.adminnav')

  		<div class="col-md-10 content">
  			  <div class="panel panel-default">
	<div class="panel-heading">
  Proposals
	</div>
	
  @yield('content')

  		<footer class="pull-left footer">
  			
  		</footer>
  	</div>

<script>
   $(function () {
  	$('.navbar-toggle-sidebar').click(function () {
  		$('.navbar-nav').toggleClass('slide-in');
  		$('.side-body').toggleClass('body-slide-in');
  		$('#search').removeClass('in').addClass('collapse').slideUp(200);
  	});

  	$('#search-trigger').click(function () {
  		$('.navbar-nav').removeClass('slide-in');
  		$('.side-body').removeClass('body-slide-in');
  		$('.search-input').focus();
  	});
  });
</script>
</body>

   

</html>



