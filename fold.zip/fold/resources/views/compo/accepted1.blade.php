
                <tbody>
                  <tr>
                    <th scope="row"><a href="\accepted\{{$accepted->id}}">{{$accepted->title}}</th></a>
                    <td>{{$accepted->submitted_by}}</td>
                    <td>{{$accepted->address}}</td>
                  
                    <td>{{$accepted->phone}}</td>
                    <td>{{$accepted->email}}</td>
                  </tr>

                </tbody>