
                <tbody>
                  <tr>
                    <th scope="row"><a href="\approved\{{$approved->id}}">{{$approved->title}}</th></a>
                    <td>{{$approved->submitted_by}}</td>
                    <td>{{$approved->address}}</td>
                  
                    <td>{{$approved->phone}}</td>
                    <td>{{$approved->email}}</td>
                  </tr>

                </tbody>