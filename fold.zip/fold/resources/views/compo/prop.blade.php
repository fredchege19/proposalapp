
                <tbody>
                  <tr>
                    <th scope="row"><a href="\infos\{{$prop->id}}">{{$prop->title}}</th></a>
                    <td>{{$prop->submitted_by}}</td>
                    <td>{{$prop->address}}</td>
                  
                    <td>{{$prop->phone}}</td>
                    <td>{{$prop->email}}</td>
                  </tr>
                 
                
                </tbody>
              