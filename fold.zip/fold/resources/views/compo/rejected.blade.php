
                <tbody>
                  <tr>
                    <th scope="row"><a href="\rejected\{{$reject->id}}">{{$reject->title}}</th></a>
                    <td>{{$reject->submitted_by}}</td>
                    <td>{{$reject->address}}</td>
                  
                    <td>{{$reject->phone}}</td>
                    <td>{{$reject->email}}</td>
                  </tr>

                </tbody>