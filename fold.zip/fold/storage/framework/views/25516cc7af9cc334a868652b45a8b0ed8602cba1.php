
                <tbody>
                  <tr>
                    <th scope="row"><a href="\accepted\<?php echo e($accepted->id); ?>"><?php echo e($accepted->title); ?></th></a>
                    <td><?php echo e($accepted->submitted_by); ?></td>
                    <td><?php echo e($accepted->address); ?></td>
                  
                    <td><?php echo e($accepted->phone); ?></td>
                    <td><?php echo e($accepted->email); ?></td>
                  </tr>

                </tbody>