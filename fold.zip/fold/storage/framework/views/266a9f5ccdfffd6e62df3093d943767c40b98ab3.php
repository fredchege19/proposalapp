
                <tbody>
                  <tr>
                    <th scope="row"><a href="\approved\<?php echo e($approved->id); ?>"><?php echo e($approved->title); ?></th></a>
                    <td><?php echo e($approved->submitted_by); ?></td>
                    <td><?php echo e($approved->address); ?></td>
                  
                    <td><?php echo e($approved->phone); ?></td>
                    <td><?php echo e($approved->email); ?></td>
                  </tr>

                </tbody>