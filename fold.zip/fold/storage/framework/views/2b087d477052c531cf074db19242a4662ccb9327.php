<?php $__env->startSection('content'); ?>
<div class="panel-body">
    <div class="col">
          <div class="card">
            <div class="card-body">
              <b><h4 class="card-title" style="color:blue;">Accepted Proposals</h4></b>
              <table class="table">
                <thead>
                  <tr>
                    <th scope="col">Title</th>
                    
                    <th scope="col">submitted by</th>
                    <th scope="col">Address</th>
                    <th scope="col">Phone</th>
                    <th scope="col">Email</th>
                  </tr>
                </thead>

       
<?php $__currentLoopData = $approveds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $approved): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo $__env->make('compo.approved', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</tbody>
              </table>
            </div>
          </div>
        </div>
	</div>
</div>
  		</div>
          <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>