<?php $__env->startSection('content'); ?>
<div class="container">
    
   
        <h3 style="text-align:center;">Hey <?php echo e(Auth::user()->name); ?> , Please Fill The Fields And Submit The Data</h3>
        <?php echo Form::open(['url' => 'save']); ?>

        <div class="form-group">
        <?php echo e(Form::label('title', 'Title')); ?>

        <?php echo e(Form::text('title', '', ['class'=>'form-control', 'value'=>''])); ?>

        </div>
        <div class="form-group">
        <?php echo e(Form::label('organisation', 'Organisation')); ?>

        <?php echo e(Form::text('organisation', '', ['class'=>'form-control', 'placeholder'=>'', 'required'=>''])); ?>

        </div>
       
        <div class="form-group">
        <?php echo e(Form::label('address', 'Address')); ?>

        <?php echo e(Form::text('address', '', ['class'=>'form-control', 'placeholder'=>''])); ?>

        </div>
        <div class="form-group">
        <?php echo e(Form::label('phone', 'Phone')); ?>

        <?php echo e(Form::text('phone', '', ['class'=>'form-control', 'placeholder'=>''])); ?>

        </div>
        <div class="form-group">
        <?php echo e(Form::label('email', 'Email')); ?>

        <?php echo e(Form::text('email', '', ['class'=>'form-control', 'placeholder'=>''])); ?>

        </div>
        <div class="form-group">
        <?php echo e(Form::label('submitted_by', 'Submitted by')); ?>

        <?php echo e(Form::text('submitted_by', '', ['class'=>'form-control', 'placeholder'=>''])); ?>

        </div>
        <div class="form-group">
        <?php echo e(Form::label('summary', 'summary')); ?>

        <?php echo e(Form::textarea('summary', '', ['class'=>'form-control', 'placeholder'=>''])); ?>

        </div>
        <div class="form-group">
        <?php echo e(Form::label('Background', 'Background')); ?>

        <?php echo e(Form::textarea('background', '', ['class'=>'form-control', 'placeholder'=>''])); ?>

        </div>
        <div class="form-group">
        <?php echo e(Form::label('Activities', 'Activities')); ?>

        <?php echo e(Form::textarea('activities', '', ['class'=>'form-control', 'placeholder'=>''])); ?>

        </div>
        <div class="form-group">
        <?php echo e(Form::label('Budget', 'Budget')); ?>

        <?php echo e(Form::textarea('budget', '', ['class'=>'form-control', 'placeholder'=>''])); ?>

        </div>
    

       
        <?php echo e(Form::submit('Save and Submit', ['class'=>'btn btn-primary'])); ?>

        
        <?php echo Form::close(); ?>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>