
<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!doctype html>
<html lang="en">

<div class="panel-body">
    <div class="col">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title"></h5>
              <table class="table">
                <thead>
                  <tr>
                    <th scope="col">Title</th>
                    <th scope="col">information</th>
                    
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <th scope="row">Proposal Title</th>
                    <th scope="row"><?php echo e($rejects->title); ?></th>
                  </tr>
                  <tr>
                    <th scope="row">Address</th>
                    <th scope="row"><?php echo e($rejects->address); ?></th>
                  </tr>
                  <tr>
                    <th scope="row">Phone</th>
                    <th scope="row"><?php echo e($rejects->phone); ?></th>
                  </tr>
                  <tr>
                    <th scope="row">Email</th>
                    <th scope="row"><?php echo e($rejects->email); ?></th>
                  </tr>
                  <tr>
                    <th scope="row">Submitted by</th>
                    <th scope="row"><?php echo e($rejects->submitted_by); ?></th>
                  </tr>
                  <tr>
                    <th scope="row">Summary</th>
                    <th scope="row"><?php echo e($rejects->summary); ?></th>
                  </tr>
                  <tr>
                    <th scope="row">Background</th>
                    <th scope="row"><?php echo e($rejects->background); ?></th>
                  </tr>
                  <tr>
                    <th scope="row">Activities</th>
                    <th scope="row"><?php echo e($rejects->activities); ?></th>
                  </tr>
                  <tr>
                    <th scope="row">Budget</th>
                    <th scope="row"><?php echo e($rejects->budget); ?></th>
                  </tr>
                 
                
                </tbody>


</tbody>
              </table>
            </div>
          </div>
        </div>
	</div>
  <form method="post" action="">
   <?php echo e(csrf_field()); ?>

   
   <div class="form-group">
   
    
   </div>
   </form>
  
  <br><br>
</div>

  		</div>
     
<script>
   $(function () {
  	$('.navbar-toggle-sidebar').click(function () {
  		$('.navbar-nav').toggleClass('slide-in');
  		$('.side-body').toggleClass('body-slide-in');
  		$('#search').removeClass('in').addClass('collapse').slideUp(200);
  	});

  	$('#search-trigger').click(function () {
  		$('.navbar-nav').removeClass('slide-in');
  		$('.side-body').removeClass('body-slide-in');
  		$('.search-input').focus();
  	});
  });
</script>
</body>

   

</html>

              