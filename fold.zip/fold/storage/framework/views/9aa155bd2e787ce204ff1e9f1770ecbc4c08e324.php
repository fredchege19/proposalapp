
                <tbody>
                  <tr>
                    <th scope="row"><a href="\rejected\<?php echo e($reject->id); ?>"><?php echo e($reject->title); ?></th></a>
                    <td><?php echo e($reject->submitted_by); ?></td>
                    <td><?php echo e($reject->address); ?></td>
                  
                    <td><?php echo e($reject->phone); ?></td>
                    <td><?php echo e($reject->email); ?></td>
                  </tr>

                </tbody>