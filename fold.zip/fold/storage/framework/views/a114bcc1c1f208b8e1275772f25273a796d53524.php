
                <tbody>
                  <tr>
                    <th scope="row"><a href="\infos\<?php echo e($prop->id); ?>"><?php echo e($prop->title); ?></th></a>
                    <td><?php echo e($prop->submitted_by); ?></td>
                    <td><?php echo e($prop->address); ?></td>
                  
                    <td><?php echo e($prop->phone); ?></td>
                    <td><?php echo e($prop->email); ?></td>
                  </tr>
                 
                
                </tbody>
              